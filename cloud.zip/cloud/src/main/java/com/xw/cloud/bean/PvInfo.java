package com.xw.cloud.bean;

public class PvInfo {
    private String pvName;
    private String pvPath;
    private String pvQuantity;
    private String pvAccessMode;

    public String getPvName() {
        return pvName;
    }

    public void setPvName(String pvName) {
        this.pvName = pvName;
    }

    public String getPvPath() {
        return pvPath;
    }

    public void setPvPath(String pvPath) {
        this.pvPath = pvPath;
    }

    public String getPvQuantity() {
        return pvQuantity;
    }

    public void setPvQuantity(String pvQuantity) {
        this.pvQuantity = pvQuantity;
    }

    public String getPvAccessMode() {
        return pvAccessMode;
    }

    public void setPvAccessMode(String pvAccessMode) {
        this.pvAccessMode = pvAccessMode;
    }
}
