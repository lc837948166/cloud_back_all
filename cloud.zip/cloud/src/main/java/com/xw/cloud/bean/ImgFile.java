package com.xw.cloud.bean;

import lombok.*;

@Builder
@Getter
@ToString
public class ImgFile {
    private String name;
    private String size;
}
