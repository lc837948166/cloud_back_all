package com.xw.cloud.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xw.cloud.bean.Template;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TemplateMapper extends BaseMapper<Template> {
//    int insertTemplate(Template temp);
//
//    Template getbyid(int id);
//    int update(Template temp);
//
//    List<Template> selectAll();
//
//    int delete(int id);
}
